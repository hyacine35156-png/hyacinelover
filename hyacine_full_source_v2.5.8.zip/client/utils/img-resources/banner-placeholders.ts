import { toProxyImage } from '@client/src/utils/image-proxy';

// Banner 图 technology 类型
export const techBannerImg1 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/technology/1.jpg');
export const techBannerImg2 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/technology/2.jpg');
export const techBannerImg3 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/technology/3.jpg');
export const techBannerImg4 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/technology/4.jpg');
export const techBannerImg5 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/technology/5.jpg');
export const techBannerImg6 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/technology/6.jpg');
export const techBannerImg7 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/technology/7.jpg');
export const techBannerImg8 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/technology/8.jpg');

// Banner 图 professional 类型
export const professionalBannerImg1 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/professional/1.jpg');
export const professionalBannerImg2 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/professional/2.jpg');
export const professionalBannerImg3 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/professional/3.jpg');
export const professionalBannerImg4 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/professional/4.jpg');
export const professionalBannerImg5 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/professional/5.jpg');
export const professionalBannerImg6 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/professional/6.jpg');
export const professionalBannerImg7 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/professional/7.jpg');
export const professionalBannerImg8 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/professional/8.jpg');

// Banner 图 minimalism 类型
export const minimalismBannerImg1 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/minimalism/1.jpg');
export const minimalismBannerImg2 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/minimalism/2.jpg');
export const minimalismBannerImg3 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/minimalism/3.jpg');
export const minimalismBannerImg4 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/minimalism/4.jpg');
export const minimalismBannerImg5 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/minimalism/5.jpg');
export const minimalismBannerImg6 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/minimalism/6.jpg');
export const minimalismBannerImg7 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/minimalism/7.jpg');
export const minimalismBannerImg8 = toProxyImage('https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/banner/minimalism/8.jpg');
